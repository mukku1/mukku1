import static org.testng.Assert.assertEquals;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

@Test
public class testCali {
	
	private StringCali cali;
	
	@BeforeTest
	public void init() {
		StringCali  cali = new StringCali();
	}
	public void emptyStringZero() throws Exception{
		StringCali  cali = new StringCali();
		assertEquals(StringCali.calcute(""),0);   
	}
	public void singleValueIsReplied() throws Exception {
		assertEquals(StringCali.calcute("1"),1);
	}
	public void twoNubmesCommaDelimitedReturnSum() throws Exception { 
		assertEquals(StringCali.calcute("1,2"),3);
	}
	
	public void twoNubmersNewLineDelimitedReturnSum() throws Exception { 
		assertEquals(StringCali.calcute("1\n2"),3);
	}
	public void threeNubmersDelimitedBothwaysReturnSum() throws Exception { 
		assertEquals(StringCali.calcute("1,2,3"),6);
	} 
	@Test(expectedExceptions= Exception.class)
	public void negativeInputReturnsException() throws Exception {
		StringCali.calcute("-1,-4,-5");
	}
}
 