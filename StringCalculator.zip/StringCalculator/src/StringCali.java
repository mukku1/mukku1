
public class StringCali {
	private final static String delimeter = ",|\\n";
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		System.out.println("Ganesh Kumar");
//		
//		
//
//	}

	public static int calcute(String input) throws Exception {
		// TODO Auto-generated method stub
		String[] numbers = input.split(delimeter);
		if(isEmpty(input)) {
			return 0;
		}if(input.length()== 1) {
			return stringTOInt(input);
		}else {
			return getSum(numbers); 
		}
		
		//return stringTOInt(input);
		
				}
	private static int getSum(String[] numbers) throws Exception {
		int sum=0;
//		for(int current =0;current< numbers.length;current++) {
//			sum += Integer.parseInt(numbers[current]);
//		}
		for(String current:numbers) {
			if(stringTOInt(current)<0) {
				throw new Exception("Negatives not allowed");
			}
		}
		for(String current:numbers) {
			sum+= Integer.parseInt(current);
			}
		
		
		return sum;
	}

	private static boolean isEmpty(String input) {
		// TODO Auto-generated method stub
		return input.isEmpty();
	}

	private static int stringTOInt(String input) {
		// TODO Auto-generated method stub
		return Integer.parseInt(input);
	}

}
